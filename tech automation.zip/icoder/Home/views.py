from django.shortcuts import render,HttpResponse
from  django.contrib import messages
from blog.models import Post

# Create your views here.
def home(request):
    return render(request,'Home/home.html')
    # return HttpResponse('this is home')

def about(request):
    return render(request,'Home/about.html')
    #return HttpResponse('this is about')

def contact(request):
    messages.success(request,'Welcome to contact')
    return render(request,'Home/contact.html')
    #return HttpResponse('this is contact')  

def search(request):
    query = request.GET['query']
    allPosts = Post.objects.filter(title__icontains= query)
    params = {'allPosts': allPosts}
    return render(request,'home/search.html',params)
    #return HttpResponse('this is search')  
        
