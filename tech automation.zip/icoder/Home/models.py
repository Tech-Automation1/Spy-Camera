from django.db import models

# Create your models here.
#databse------> excel workbook
#models in django------> table------>sheet

class Contact(models.Model):
    sno = models.AutoField(primary_key =True)
    name = models.CharField(max_length=250)
    phone = models.CharField(max_length=10)
    email = models.CharField(max_length=300)
    content = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True, blank=True)
