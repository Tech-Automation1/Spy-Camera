from django.shortcuts import render,HttpResponse
from .models import Post

# Create your views here.
def bloghome(request):
    allPosts = Post.objects.all()
    Context = {'allPosts': allPosts}
    return render(request,'blog/bloghome.html',Context)
    #return HttpResponse('this is bloghome: we will all the blogpost here')

def blogpost(request,slug):
    Post = Post.objects.filter(slug=slug).first()
    context = {'Post': Post}
    return render(request,'blog/blogpost.html', context)
    #return HttpResponse(f'this is blogpost:{slug}')

